const http = require("https");

const URL = "https://translate.googleapis.com/translate_a/single";

class TranslationMode {
    static SINGLE = "t";
    static MULTIPLE = "at";
    static PRONUNCIATION = "rm";
}

module.exports.translate = (word, from, to) =>
    new Promise((resolve, reject) => {
        const params = {
            client: "gtx",
            sl: from,
            tl: to,
            dt: TranslationMode.MULTIPLE,
            q: word, // query or string to be translated
        };

        const paramString = Object.entries(params)
            .map((keyValue) => keyValue.join("="))
            .join("&");
        const url = URL + "?" + paramString;

        try {
            http.get(url, (res) => {
                res.on("data", (data) => {
                    const json = JSON.parse(data);
                    const results = json[5][0][2].map((x) => x[0]);
                    resolve(results);
                });
            });
        } catch (err) {
            reject(err);
        }
    });
