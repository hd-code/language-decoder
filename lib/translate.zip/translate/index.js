module.exports.translate = require("./translate").translate;
