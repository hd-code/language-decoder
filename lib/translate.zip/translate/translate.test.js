const assert = require("assert/strict");
const translate = require("./translate").translate;

async function main() {
    const res = await translate("house", "en", "de");
    assert(res instanceof Array);
    assert(res.includes("Haus"));
}

console.log("testing", __dirname + "/translate.js", "...");
main()
    .then(() => console.log("  SUCCESS"))
    .catch((err) => console.log("  ERROR !!!\n", err));
