export declare function translate(word: string, from: string, to: string): Promise<string[]>;
